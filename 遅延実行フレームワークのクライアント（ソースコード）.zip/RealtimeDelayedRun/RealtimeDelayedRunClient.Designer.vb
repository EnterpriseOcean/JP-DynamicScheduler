﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RealtimeDelayedRunClient
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.UserNameLabel = New System.Windows.Forms.Label()
        Me.UserNameText = New System.Windows.Forms.TextBox()
        Me.PasswordLabel = New System.Windows.Forms.Label()
        Me.PasswordText = New System.Windows.Forms.TextBox()
        Me.GetProcessInfoButton = New System.Windows.Forms.Button()
        Me.ProcessList = New System.Windows.Forms.ComboBox()
        Me.RunProcessButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'UserNameLabel
        '
        Me.UserNameLabel.AutoSize = True
        Me.UserNameLabel.Font = New System.Drawing.Font("Meiryo UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.UserNameLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.UserNameLabel.Location = New System.Drawing.Point(17, 15)
        Me.UserNameLabel.Name = "UserNameLabel"
        Me.UserNameLabel.Size = New System.Drawing.Size(75, 19)
        Me.UserNameLabel.TabIndex = 0
        Me.UserNameLabel.Text = "ユーザー名"
        '
        'UserNameText
        '
        Me.UserNameText.Font = New System.Drawing.Font("Meiryo UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.UserNameText.Location = New System.Drawing.Point(111, 12)
        Me.UserNameText.Name = "UserNameText"
        Me.UserNameText.Size = New System.Drawing.Size(186, 27)
        Me.UserNameText.TabIndex = 1
        '
        'PasswordLabel
        '
        Me.PasswordLabel.AutoSize = True
        Me.PasswordLabel.Font = New System.Drawing.Font("Meiryo UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.PasswordLabel.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.PasswordLabel.Location = New System.Drawing.Point(17, 51)
        Me.PasswordLabel.Name = "PasswordLabel"
        Me.PasswordLabel.Size = New System.Drawing.Size(70, 19)
        Me.PasswordLabel.TabIndex = 2
        Me.PasswordLabel.Text = "パスワード"
        '
        'PasswordText
        '
        Me.PasswordText.Font = New System.Drawing.Font("Meiryo UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.PasswordText.Location = New System.Drawing.Point(111, 48)
        Me.PasswordText.Name = "PasswordText"
        Me.PasswordText.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.PasswordText.Size = New System.Drawing.Size(186, 27)
        Me.PasswordText.TabIndex = 3
        '
        'GetProcessInfoButton
        '
        Me.GetProcessInfoButton.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.GetProcessInfoButton.Font = New System.Drawing.Font("Meiryo UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.GetProcessInfoButton.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.GetProcessInfoButton.Location = New System.Drawing.Point(21, 102)
        Me.GetProcessInfoButton.Name = "GetProcessInfoButton"
        Me.GetProcessInfoButton.Size = New System.Drawing.Size(188, 36)
        Me.GetProcessInfoButton.TabIndex = 4
        Me.GetProcessInfoButton.Text = "実行できるプロセスを取得"
        Me.GetProcessInfoButton.UseVisualStyleBackColor = False
        '
        'ProcessList
        '
        Me.ProcessList.Font = New System.Drawing.Font("Meiryo UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ProcessList.FormattingEnabled = True
        Me.ProcessList.Location = New System.Drawing.Point(21, 148)
        Me.ProcessList.Name = "ProcessList"
        Me.ProcessList.Size = New System.Drawing.Size(276, 27)
        Me.ProcessList.TabIndex = 5
        '
        'RunProcessButton
        '
        Me.RunProcessButton.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.RunProcessButton.Font = New System.Drawing.Font("Meiryo UI", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.RunProcessButton.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.RunProcessButton.Location = New System.Drawing.Point(112, 190)
        Me.RunProcessButton.Name = "RunProcessButton"
        Me.RunProcessButton.Size = New System.Drawing.Size(185, 35)
        Me.RunProcessButton.TabIndex = 6
        Me.RunProcessButton.Text = "選択したプロセスを実行"
        Me.RunProcessButton.UseVisualStyleBackColor = False
        '
        'RealtimeDelayedRunClient
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkOliveGreen
        Me.ClientSize = New System.Drawing.Size(320, 240)
        Me.Controls.Add(Me.RunProcessButton)
        Me.Controls.Add(Me.ProcessList)
        Me.Controls.Add(Me.GetProcessInfoButton)
        Me.Controls.Add(Me.PasswordText)
        Me.Controls.Add(Me.PasswordLabel)
        Me.Controls.Add(Me.UserNameText)
        Me.Controls.Add(Me.UserNameLabel)
        Me.Name = "RealtimeDelayedRunClient"
        Me.Text = "リアルタイム起動・遅延実行クライアント"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents UserNameLabel As Label
    Friend WithEvents UserNameText As TextBox
    Friend WithEvents PasswordLabel As Label
    Friend WithEvents PasswordText As TextBox
    Friend WithEvents GetProcessInfoButton As Button
    Friend WithEvents ProcessList As ComboBox
    Friend WithEvents RunProcessButton As Button
End Class
