﻿Public Class RealtimeDelayedRunClient
    Private Sub RunProcessButton_Click(sender As Object, e As EventArgs) Handles RunProcessButton.Click

        Dim client As New ReceptionDelayedRun.ReceptionDelayedRunPortTypeClient

        Try


            '認証情報をHTTPリクエストに設定
            client.ClientCredentials.UserName.UserName = UserNameText.Text
            client.ClientCredentials.UserName.Password = PasswordText.Text

            'プロセスの実行リクエストを送信
            client.AddQueueItem("auto", ProcessList.Text, UserNameText.Text, PasswordText.Text)

            '実行できるプロセスのリストをクリア
            ProcessList.Text = ""

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub

    Private Sub GetProcessInfoButton_Click(sender As Object, e As EventArgs) Handles GetProcessInfoButton.Click

        Dim client As New ReceptionJP.ReceptionJPPortTypeClient

        Try
            Dim processInfo As New ReceptionJP.GetProcessInfo
            Dim processInfoResponse As ReceptionJP.GetProcessInfoResponse
            Dim processes As ReceptionJP.GetProcessInfoOutProcessesRow()

            '認証情報をHTTPリクエストに設定
            client.ClientCredentials.UserName.UserName = UserNameText.Text
            client.ClientCredentials.UserName.Password = PasswordText.Text

            'プロセスの情報を取得
            'Web API ProcessInfo を呼び出し
            processInfo.bpInstance = "auto"
            processInfoResponse = client.GetProcessInfo(processInfo)
            processes = processInfoResponse.Processes

            'コンボボックスに値を設定
            ProcessList.Items.Clear()
            For i = 0 To processes.Length - 1
                ProcessList.Items.Add(processes.ElementAt(i).name)
            Next i
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

    End Sub
End Class
